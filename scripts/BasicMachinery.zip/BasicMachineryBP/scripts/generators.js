import * as mc from "@minecraft/server"
import {generate, generateRemaining} from "./globalTubes.js"
import {setPermutation} from "./system.js"
import {isBlockId} from "./stableTriggers.js"
